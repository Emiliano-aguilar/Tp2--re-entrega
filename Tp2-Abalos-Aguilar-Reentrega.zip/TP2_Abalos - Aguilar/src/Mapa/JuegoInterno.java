package Mapa;

import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.JMapViewer;
import org.openstreetmap.gui.jmapviewer.MapMarkerDot;
import org.openstreetmap.gui.jmapviewer.MapPolygonImpl;
import org.openstreetmap.gui.jmapviewer.interfaces.MapMarker;
import org.openstreetmap.gui.jmapviewer.interfaces.MapPolygon;

public class JuegoInterno {
	private ArrayList<String> cordenadasString;
	private ArrayList<Tupla<Double, Double>> cordenadassTupla;
	private JMapViewer mapa;
	private ArrayList<Tupla<Double, Double>> cordenadas;
	private MapMarker[] puntos;
	private GrafoListaDeVecinos grafo;
	private HashSet<MapPolygon> polygon = new HashSet<MapPolygon>();
	private Coordinate locacion = new Coordinate(-34.54334555, -58.690464534);
	private HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados;
	private ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristas;

	public HashSet<Tupla<Double, Double>> getConjuntoVerticesUtilizados() {
		return conjuntoVerticesUtilizados;
	}

	private ArrayList<Double> distanciaAristas;
	private Double inicializar0 = 0.0;

	public JuegoInterno() {
		cordenadasString = new ArrayList<String>();
		cordenadassTupla = new ArrayList<Tupla<Double, Double>>();

	}

	protected void leerArchivo() {

		File archivo = new File("Cordenadas.txt");
		try {
			FileInputStream fis = new FileInputStream(archivo);
			Scanner scanner = new Scanner(fis);
			while (scanner.hasNextLine()) {
				String linea = scanner.nextLine();
				cordenadasString.add(linea);

			}
			scanner.close();
			pasarATupla(cordenadasString);

		} catch (FileNotFoundException e) {

		}

	}

	protected void pasarATupla(ArrayList<String> cordenadas) {
		for (int i = 0; i < cordenadas.size(); i = i + 2) {
			Tupla<Double, Double> tupla = new Tupla<Double, Double>(convertirADecimal(cordenadas.get(i)),
					convertirADecimal(cordenadas.get(i + 1)));
			cordenadassTupla.add(tupla);
		}
	}

	protected ArrayList<Tupla<Double, Double>> dameCordenadas() {
		return (ArrayList<Tupla<Double, Double>>) cordenadassTupla.clone();
	}

	protected Integer cantidadDeCordenadas() {
		return cordenadassTupla.size();
	}

	protected Integer cantidadEntradasLeidas() {
		return cordenadasString.size();
	}

	private Double convertirADecimal(String cords2) {
		Double newCord = Double.parseDouble(cords2);
		return newCord;
	}

	protected ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> algoritmoPrim(GrafoListaDeVecinos g,
			ArrayList<Tupla<Double, Double>> cordenadas) {
		conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		Double actual = inicializar0;
		Double min = Double.MAX_VALUE;
		boolean flag = false;
		Tupla<Double, Double> tuplaAuxFor1 = null;
		Tupla<Double, Double> tuplaAuxFor2 = null;
		distanciaAristas = new ArrayList<Double>();
		ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristasAux = new ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>>();

		GrafoListaDeVecinos grafoAux = new GrafoListaDeVecinos(cantidadDeCordenadas());
		llenarGrafoAux(grafoAux, cordenadas);

		conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		conjuntoVerticesUtilizados.add(cordenadas.get(0));

		for (int i = 0; i < cordenadas.size(); i++) {

			for (Tupla<Double, Double> tupla : conjuntoVerticesUtilizados) {
				for (Tupla<Double, Double> tupla2 : cordenadas) {

					if (!tupla.sonIguales(tupla2)
							&& !g.existeArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2))
							&& !conjuntoVerticesUtilizados.contains(tupla2)) {

						if (!esVecinoDeVecino(conjuntoVerticesUtilizados, tupla2, g)) {
							actual = g.distanciaFinal(tupla, tupla2);
							if (actual < min) {
								min = actual;
								tuplaAuxFor1 = tupla;
								tuplaAuxFor2 = tupla2;
								flag = true;
							}

						}

					}

				} // cierra el tercer for

			} // cierra el segundo for

			if (flag) {
				g.agregarArista(cordenadas.indexOf(tuplaAuxFor1), cordenadas.indexOf(tuplaAuxFor2));
				Tupla<Tupla<Double, Double>, Tupla<Double, Double>> Vertice = new Tupla<Tupla<Double, Double>, Tupla<Double, Double>>(
						tuplaAuxFor1, tuplaAuxFor2);
				aristasAux.add(Vertice);
				distanciaAristas.add(min);
				conjuntoVerticesUtilizados.add(tuplaAuxFor1);
				conjuntoVerticesUtilizados.add(tuplaAuxFor2);
				tuplaAuxFor1 = null;
				tuplaAuxFor2 = null;
				Vertice = null;
				flag = false;
				min = Double.MAX_VALUE;
				actual = inicializar0;

			}

		}

		return aristasAux;

	}

	public JMapViewer generarClouster(GrafoListaDeVecinos g, int cantClouster,
			ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristas2, JMapViewer mapa2,
			ArrayList<Tupla<Double, Double>> cordenadas2) {

		int e = 0;
		while (e < cantClouster - 1) {
			int aristaABorrar = buscarAristaMasLarga(distanciaAristas);
			g.eliminarArista(cordenadas2.indexOf(aristas2.get(aristaABorrar).getX()),
					cordenadas2.indexOf(aristas2.get(aristaABorrar).getY()));
			aristas2.remove(aristaABorrar);
			e++;
		}

		for (int i = 0; i < aristas2.size(); i++) {
			ArrayList<Coordinate> aristasADibujarAux = new ArrayList<Coordinate>();

			aristasADibujarAux.add(new Coordinate(aristas2.get(i).getX().getX(), aristas2.get(i).getX().getY()));
			aristasADibujarAux.add(new Coordinate(aristas2.get(i).getY().getX(), aristas2.get(i).getY().getY()));
			aristasADibujarAux.add(new Coordinate(aristas2.get(i).getX().getX(), aristas2.get(i).getX().getY()));

			MapPolygon clauster = new MapPolygonImpl(aristasADibujarAux);
			clauster.getStyle().setColor(Color.GREEN);
			polygon.add(clauster);
			aristasADibujarAux = null;
			clauster = null;

		}

		for (MapPolygon clau : polygon) {
			mapa2.addMapPolygon(clau);
		}

		return mapa2;
	}

	protected boolean esVecinoDeVecino(HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados,
			Tupla<Double, Double> tuplaAnalizar, GrafoListaDeVecinos grafo) {
		boolean flag = false;
		for (int i = 0; i < conjuntoVerticesUtilizados.size(); i++) {
			flag = flag || conjuntoVerticesUtilizados.contains(tuplaAnalizar);
		}

		return flag;
	}

	protected GrafoListaDeVecinos llenarGrafoAux(GrafoListaDeVecinos grafoAux,
			ArrayList<Tupla<Double, Double>> cordenadas) {

		for (Tupla<Double, Double> tupla : cordenadas) { // A ---- B
			for (Tupla<Double, Double> tupla2 : cordenadas) { // B C D ===== 5 2da itenracion

				if (!tupla.sonIguales(tupla2)
						&& !grafoAux.existeArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2))) {
					grafoAux.agregarArista(cordenadas.indexOf(tupla), cordenadas.indexOf(tupla2));
				}
			}
		}

		return grafoAux;
	}

	private void definirTamanio(Integer cantCordenadas) {
		puntos = new MapMarker[cantCordenadas];
	}

	private void dibujamePuntos(ArrayList<Tupla<Double, Double>> cordenadas2) {
		for (int i = 0; i < cordenadas2.size(); i++) {
			InicializarPuntos(cordenadas2.get(i), i);
		}

	}

	private void InicializarPuntos(Tupla<Double, Double> cords, Integer pos) {
		MapMarker marker = new MapMarkerDot(cords.getX(), cords.getY());
		marker.getStyle().setBackColor(Color.BLUE);
		marker.getStyle().setColor(Color.BLACK);
		puntos[pos] = marker;
		mapa.addMapMarker(marker);

		marker = null;
	}

	protected int buscarAristaMasLarga(ArrayList<Double> distanciaAristas) {
		double distanciaMax = Double.MIN_VALUE;
		for (int i = 0; i < distanciaAristas.size(); i++) {
			if (distanciaMax < distanciaAristas.get(i)) {
				distanciaMax = distanciaAristas.get(i);
			}

		}

		return distanciaAristas.indexOf(distanciaMax);

	}

	public JMapViewer main(int cantClouster) {
		mapa = new JMapViewer();
		mapa.setDisplayPosition(locacion, 12);

		leerArchivo();
		definirTamanio(cantidadDeCordenadas());
		cordenadas = dameCordenadas();
		grafo = new GrafoListaDeVecinos(cantidadDeCordenadas());

		dibujamePuntos(cordenadassTupla);
		aristas = algoritmoPrim(grafo, cordenadas);

		return generarClouster(grafo, cantClouster, aristas, mapa, cordenadas);

	}

}
