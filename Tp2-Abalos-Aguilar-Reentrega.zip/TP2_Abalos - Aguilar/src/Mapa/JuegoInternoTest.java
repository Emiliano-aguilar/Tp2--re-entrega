package Mapa;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.openstreetmap.gui.jmapviewer.Coordinate;
import org.openstreetmap.gui.jmapviewer.JMapViewer;
import org.openstreetmap.gui.jmapviewer.interfaces.MapPolygon;

public class JuegoInternoTest {

	@Before
	public void setUp() throws Exception {

	}

	@Test
	public void leerArchivoTest() {
		JuegoInterno nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		Integer cantidadLeidas = nuevo.cantidadEntradasLeidas();
		assertTrue(cantidadLeidas.equals(136));
	}

	@Test
	public void cantidadDeTuplasTest() {
		JuegoInterno nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		Integer cantidadTuplas = nuevo.cantidadDeCordenadas();
		assertTrue(cantidadTuplas.equals(136 / 2));
	}

	@Test
	public void cantidadDeTuplasIncorrectoTest() {
		JuegoInterno nuevo = new JuegoInterno();
		nuevo.leerArchivo();
		Integer cantidadTuplas = nuevo.cantidadDeCordenadas();
		assertFalse(cantidadTuplas.equals((136 / 2) + 2));
	}

	@Test
	public void pasarATuplaTest() {
		JuegoInterno nuevo = new JuegoInterno();
		ArrayList<String> arr = new ArrayList<String>();
		arr.add("-32.564");
		arr.add("-54.342");
		nuevo.pasarATupla(arr);
		Tupla<Double, Double> tuplaAnalizar = new Tupla<Double, Double>(-32.564, -54.342);
		assertTrue(nuevo.dameCordenadas().get(0).sonIguales(tuplaAnalizar));
	}

	@Test
	public void llenarGrafoAuxCorrecto() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos g = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();

		GrafoListaDeVecinos grafoAux = juego.llenarGrafoAux(g, cordenadas);

		assertEquals(g.tamano(), grafoAux.tamano());
	}

	@Test
	public void llenarGrafoAuxIgual() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos g = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		GrafoListaDeVecinos grafoAux = juego.llenarGrafoAux(g, cordenadas);

		assertTrue(g.equals(grafoAux));
	}

	@Test
	public void llenarGrafoAuxIncorrecto() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos g = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();

		GrafoListaDeVecinos grafoAux = juego.llenarGrafoAux(g, cordenadas);
		boolean flag = g.tamano() == (grafoAux.tamano() + 1);
		assertFalse(flag);
	}

	@Test
	public void buscarAristaMasLarga() {
		ArrayList<Double> distanciaAristas = new ArrayList<Double>();
		JuegoInterno juego = new JuegoInterno();
		Double respuestaCorrecta = 10.2;
		distanciaAristas.add(5.0);
		distanciaAristas.add(7.0);
		distanciaAristas.add(10.0);
		distanciaAristas.add(10.1);
		distanciaAristas.add(respuestaCorrecta);
		int lugarResultado = distanciaAristas.indexOf(respuestaCorrecta);
		int respuesta = juego.buscarAristaMasLarga(distanciaAristas);
		assertEquals(lugarResultado, respuesta);
	}

	@Test
	public void esVecinoDeVecinosTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());

		Tupla<Double, Double> tuplaAnalizar = new Tupla<Double, Double>(34.2354, 34.516);
		Tupla<Double, Double> tuplaRandom = new Tupla<Double, Double>(55.2354, 55.516);

		HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		conjuntoVerticesUtilizados.add(tuplaRandom);

		assertFalse(juego.esVecinoDeVecino(conjuntoVerticesUtilizados, tuplaAnalizar, grafo));
	}

	// si la tupla a analizar, ya esta dentro del conjuntoVerticesUtilizados,
	// entonces es verdadero que es vecino de vecinos
	@Test
	public void esVecinoDeVecinosErroneoTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		Tupla<Double, Double> tuplaAnalizar = new Tupla<Double, Double>(34.2354, 34.516);

		HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		conjuntoVerticesUtilizados.add(tuplaAnalizar);

		assertTrue(juego.esVecinoDeVecino(conjuntoVerticesUtilizados, tuplaAnalizar, grafo));
	}

	@Test
	public void esVecinoDeVecinosErroneoNullTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());

		HashSet<Tupla<Double, Double>> conjuntoVerticesUtilizados = new HashSet<Tupla<Double, Double>>();
		conjuntoVerticesUtilizados.add(null);

		assertTrue(juego.esVecinoDeVecino(conjuntoVerticesUtilizados, null, grafo));
	}

	// faltan hacer
	@Test
	public void algoritmoPrimRetornNUllTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		assertNotEquals(null, juego.algoritmoPrim(grafo, cordenadas));
	}

	@Test
	public void algoritmoPrimCantAristasCreadasTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristas = juego.algoritmoPrim(grafo, cordenadas);
		assertEquals(grafo.tamano(), aristas.size() + 1);
	}

	@Test
	public void algoritmoPrimContieneTodosLosVerticesTest() {
		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		ArrayList<Tupla<Tupla<Double, Double>, Tupla<Double, Double>>> aristas = juego.algoritmoPrim(grafo, cordenadas);
		HashSet<Tupla<Double, Double>> ConjuntoVerticesUtilizados = juego.getConjuntoVerticesUtilizados();
		assertEquals(grafo.tamano(), ConjuntoVerticesUtilizados.size());
	}

	@Test
	public void generarClousterTest() {
		JMapViewer mapa = new JMapViewer();
		JMapViewer mapaVacio = new JMapViewer();

		Coordinate locacion = new Coordinate(-34.54334555, -58.690464534);
		mapa.setDisplayPosition(locacion, 12);

		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		assertNotEquals(mapaVacio,
				juego.generarClouster(grafo, 0, juego.algoritmoPrim(grafo, cordenadas), mapa, cordenadas));
	}

	@Test
	public void generarClousterDistintosTest() {
		JMapViewer mapa = new JMapViewer();
		JMapViewer mapaVacio = new JMapViewer();

		Coordinate locacion = new Coordinate(-34.54334555, -58.690464534);
		mapa.setDisplayPosition(locacion, 12);

		JuegoInterno juego = new JuegoInterno();
		juego.leerArchivo();
		GrafoListaDeVecinos grafo = new GrafoListaDeVecinos(juego.cantidadDeCordenadas());
		ArrayList<Tupla<Double, Double>> cordenadas = juego.dameCordenadas();
		assertNotEquals(juego.generarClouster(grafo, 2, juego.algoritmoPrim(grafo, cordenadas), mapaVacio, cordenadas),
				juego.generarClouster(grafo, 0, juego.algoritmoPrim(grafo, cordenadas), mapa, cordenadas));
	}
}
