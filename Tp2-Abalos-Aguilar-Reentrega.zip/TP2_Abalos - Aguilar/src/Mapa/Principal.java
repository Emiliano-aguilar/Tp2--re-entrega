package Mapa;

import java.awt.EventQueue;

import javax.swing.JFrame;
import org.openstreetmap.gui.jmapviewer.JMapViewer;
import javax.swing.JPanel;


import java.awt.SystemColor;

import javax.swing.JOptionPane;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class Principal {

	private JFrame frame;
	private JuegoInterno nuevo;
	private JMapViewer mapa;
	private JPanel panelMapa;	
	private Integer clusters ;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Principal window = new Principal();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Principal() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		frame = new JFrame();
		frame.getContentPane().setBackground(SystemColor.textHighlight);
		frame.setBounds(100, 100, 462, 532);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.setTitle("JMap Tp");
		
		panelMapa = new JPanel();
		panelMapa.setBounds(10, 25, 422, 420);
		frame.getContentPane().add(panelMapa);
		
		String valor = JOptionPane.showInputDialog("INGRESE LA CANTIDAD DE CLUSTERS");
		clusters = Integer.parseInt(valor);
		
		nuevo = new JuegoInterno();
		mapa = nuevo.main(clusters);
		panelMapa.add(mapa);
		
		
	}


	

}
